package uia.com.api.inventario.dto;

import java.util.ArrayList;
import java.util.List;


public class SolicitudEntregaDTO {
    private String id;


    public SolicitudEntregaDTO() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


}
