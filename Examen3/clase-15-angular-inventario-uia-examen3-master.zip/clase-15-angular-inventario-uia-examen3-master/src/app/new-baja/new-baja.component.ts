import { Component } from '@angular/core';

@Component({
  selector: 'app-new-baja',
  templateUrl: './new-baja.component.html',
  styleUrls: ['./new-baja.component.css']
})
export class NewBajaComponent {

}
