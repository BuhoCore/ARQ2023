import { Component } from '@angular/core';

@Component({
  selector: 'app-consulta-baja',
  templateUrl: './consulta-baja.component.html',
  styleUrls: ['./consulta-baja.component.css']
})
export class ConsultaBajaComponent {

}
