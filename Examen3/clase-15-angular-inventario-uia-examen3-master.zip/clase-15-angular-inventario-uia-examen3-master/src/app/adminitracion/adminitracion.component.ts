import { Component } from '@angular/core';

@Component({
  selector: 'app-adminitracion',
  templateUrl: './adminitracion.component.html',
  styleUrls: ['./adminitracion.component.css']
})
export class AdminitracionComponent {

}
