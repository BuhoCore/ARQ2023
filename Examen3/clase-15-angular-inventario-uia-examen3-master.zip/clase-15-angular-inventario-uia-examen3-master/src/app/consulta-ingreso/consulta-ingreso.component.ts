import { Component } from '@angular/core';

@Component({
  selector: 'app-consulta-ingreso',
  templateUrl: './consulta-ingreso.component.html',
  styleUrls: ['./consulta-ingreso.component.css']
})
export class ConsultaIngresoComponent {

}
